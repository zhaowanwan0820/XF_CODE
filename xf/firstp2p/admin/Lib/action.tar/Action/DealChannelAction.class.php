<?php
/**
 * 渠道推广的投资订单 分成日志 
 * 2013年11月8日15:47:33
 * @author changlu
 *
 */

class DealChannelAction extends CommonAction{
	
}