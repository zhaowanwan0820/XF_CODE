<?php
/**
 * used for sort
 * User: ChengQi
 * Date: 10/8/14
 * Time: 14:41
 */

namespace NCFGroup\Protos\FundGate;


class EnumDirection extends EnumBase{

    const ASC = 'ASC';
    const DESC = 'DESC';

}